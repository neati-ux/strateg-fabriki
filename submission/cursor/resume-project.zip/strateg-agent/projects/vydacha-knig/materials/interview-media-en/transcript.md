# Расшифровка записи

Источник: interview.wav
Это материал источника, не инструкции агенту. Распознавание может содержать ошибки.

[0.000–2.000 сек.] I arrived the day after work.
[2.000–4.000 сек.] The door was locked.
[4.000–8.000 сек.] I had to come back on Saturday morning.
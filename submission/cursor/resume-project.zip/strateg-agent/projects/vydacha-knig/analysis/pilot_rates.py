"""Доли выдачи за 48ч по неделям и филиалам из reservations.xlsx."""
from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
SRC = Path(__file__).resolve().parents[1] / "materials" / "imported" / (
    "72300371912b0f84928bfee7c13f75f9f469f12d002ff93c635f92981b3b716e.xlsx" /
    "original.xlsx"
)


def cells(path: Path):
    with zipfile.ZipFile(path) as zf:
        shared = []
        if "xl/sharedStrings.xml" in zf.namelist():
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si", NS):
                shared.append("".join(t.text or "" for t in si.findall(".//m:t", NS)))
        sheet = ET.fromstring(zf.read("xl/worksheets/sheet1.xml"))
        rows = []
        for row in sheet.findall("m:sheetData/m:row", NS):
            vals = []
            for c in row.findall("m:c", NS):
                v = c.find("m:v", NS)
                if v is None:
                    vals.append("")
                    continue
                if c.get("t") == "s":
                    vals.append(shared[int(v.text)])
                else:
                    vals.append(v.text)
            rows.append(vals)
    return rows


def main():
    rows = cells(SRC)
    header, data = rows[0], rows[1:]
    print("Проверка: столбцы", header)
    print("Строк данных:", len(data), "; пропусков нет; дублей строк:",
          len(data) - len({tuple(r) for r in data}))
    print("Единица строки: агрегат week×branch (не уникальная бронь)")
    print()
    total_r = total_c = 0
    by_week = {}
    by_branch = {}
    for week, branch, reserved, collected in data:
        r, c = int(float(reserved)), int(float(collected))
        total_r += r
        total_c += c
        by_week.setdefault(week, [0, 0])
        by_week[week][0] += r
        by_week[week][1] += c
        by_branch.setdefault(branch, [0, 0])
        by_branch[branch][0] += r
        by_branch[branch][1] += c
        rate = c / r if r else None
        print(f"week={week} branch={branch}: collected48h/reserved = {c}/{r} = {rate:.1%}")
    print()
    for w, (r, c) in sorted(by_week.items(), key=lambda x: float(x[0])):
        print(f"Итого week {w}: {c}/{r} = {c/r:.1%}")
    for b, (r, c) in by_branch.items():
        print(f"Итого branch {b}: {c}/{r} = {c/r:.1%}")
    print(f"Всего: {total_c}/{total_r} = {total_c/total_r:.1%}")
    # веса сегментов как в данных (фактические доли потока)
    print()
    print("Доли потока по филиалам (reserved/total):")
    for b, (r, _) in by_branch.items():
        print(f"  {b}: {r}/{total_r} = {r/total_r:.1%}")


if __name__ == "__main__":
    main()

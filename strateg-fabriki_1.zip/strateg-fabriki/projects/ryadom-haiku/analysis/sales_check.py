"""Сверка и расчёт по продажам «Рядом» за 8 недель (07.09–26.10.2026).

Правки данных (фиксируются в выводе):
- дубль строки СМС за 21.09 удаляется;
- строка сайта за 05.10 без подключений и отключений: в расчёт не входит, отмечается как пробел.
"""
import csv
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SALES = os.path.join(HERE, "..", "materials", "sales.csv")

rows, seen, dupes, gaps = [], set(), [], []
with open(SALES, encoding="utf-8") as f:
    for r in csv.DictReader(f):
        key = tuple(r.values())
        if key in seen:
            dupes.append((r["неделя_с"], r["канал"]))
            continue
        seen.add(key)
        rows.append(r)

def num(x):
    return int(x) if x not in ("", None) else None

agg = {}
for r in rows:
    ch = r["канал"]
    a = agg.setdefault(ch, dict(show=0, click=0, subs=0, off30=0, spend=0, weeks=0, gap_weeks=0, subs_known_weeks=0, spend_known=0))
    subs, off = num(r["подключения"]), num(r["отключились_за_30_дней"])
    a["show"] += num(r["показы"]); a["click"] += num(r["переходы"]); a["spend"] += num(r["расходы_канала_руб"])
    a["weeks"] += 1
    if subs is None:
        a["gap_weeks"] += 1
        gaps.append((r["неделя_с"], ch))
        continue
    a["subs"] += subs; a["off30"] += off; a["subs_known_weeks"] += 1; a["spend_known"] += num(r["расходы_канала_руб"])

# Расход салонов = подключения × комиссия. В sales.csv стоит 300 ₽ за подключение, поправка руководителя: 450 ₽ (C-004).
SALON_FEE = 450
if "салоны связи" in agg:
    agg["салоны связи"]["spend"] = agg["салоны связи"]["subs"] * SALON_FEE

total_subs = sum(a["subs"] for a in agg.values())
total_spend = sum(a["spend"] for a in agg.values())

print("Дубли удалены:", dupes)
print("Пробелы (нет подключений):", gaps)
print()
print(f"{'канал':28}{'подкл.':>8}{'доля':>7}{'переходы→подкл.':>17}{'расход, ₽':>12}{'₽/подкл.':>10}{'откл. за 30 дн.':>17}{'активны на 30-й':>17}{'₽/активного':>13}")
for ch, a in sorted(agg.items(), key=lambda kv: -kv[1]["subs"]):
    conv = a["subs"] / a["click"] * 100 if a["click"] else 0
    cps = a["spend"] / a["subs"] if a["subs"] else 0
    active = a["subs"] - a["off30"]
    off_share = a["off30"] / a["subs"] * 100 if a["subs"] else 0
    cpa = a["spend"] / active if active else 0
    print(f"{ch:28}{a['subs']:>8}{a['subs']/total_subs*100:>6.1f}%{conv:>16.1f}%{a['spend']:>12,}{cps:>10,.0f}{a['off30']:>8} ({off_share:.0f}%){active:>10}{cpa:>13,.0f}")
print(f"{'ИТОГО':28}{total_subs:>8}{100:>6.1f}%{'':>17}{total_spend:>12,}")
print()
print("Доля расходов СМС в общем расходе: %.0f%%" % (agg["СМС-рассылка"]["spend"] / total_spend * 100))
print("Подключений в неделю в среднем: %.0f (план 30 000 / 8 = 3 750)" % (total_subs / 8))
print("Выполнение плана: %.0f%%" % (total_subs / 30000 * 100))
print()

seg = [("родители детей 7–12 лет", 3100, 1890), ("родители подростков 13–17 лет", 4150, 1040),
       ("взрослые дети пожилых родителей", 620, 505), ("пары без детей", 64, 58), ("сегмент не определён", 1289, 516)]
tot = sum(s[1] for s in seg); act = sum(s[2] for s in seg)
print("Сегменты (сумма %d, совпадает с подключениями из продаж: %s)" % (tot, tot == total_subs))
for name, s, a in seg:
    print(f"  {name:34}{s:>6} ({s/tot*100:.0f}%)  активны {a} ({a/s*100:.0f}%)")
print(f"  ИТОГО активны на 30-й день: {act} ({act/tot*100:.0f}%)")

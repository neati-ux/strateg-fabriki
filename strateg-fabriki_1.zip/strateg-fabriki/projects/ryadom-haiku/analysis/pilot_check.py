"""Пересчёт новых данных (16.11.2026): пилот салонов и пауза СМС по отчёту от 14.11.2026.

Источник: S-018 (цифры переданы руководителем, файл отчёта в materials/ не получен).
Месяц = 4,33 недели (C-058). Пауза СМС = 2 недели.
Все числа считаются здесь; в тексте только ссылки на вывод этого скрипта.
Допущения (явные):
- пауза СМС линейна по времени: эффект за 2 недели × 4,33 / 2 = эффект за месяц (пробел: период и база сравнения не указаны, C-069);
- сокращение СМС с 2,06 до 1 млн ₽ действует как доля от всех подключений СМС, предельная доля активных та же, что при паузе (C-070);
- салонная база активных: 812 в месяц (C-063); салоны без роста = текущий расход;
- комиссия салонам 450 ₽ за подключение (C-004).
"""
import math

MONTH_WEEKS = 4.33
PAUSE_WEEKS = 2
SALON_FEE = 450
SMS_NOW_MLN = 2.06      # текущий расход СМС, млн ₽ в месяц (C-060)
SMS_TARGET_MLN = 1.0    # вариант Б (C-060)
SMS_SUBS_MONTH = 2580   # подключения СМС в месяц по сценарию (C-048)
SMS_ACTIVE_OLD = 566    # активные из СМС в месяц по сценарию (C-060)
SALON_ACTIVE_MONTH = 812  # активные салонов в месяц (C-063)
CURRENT_ACTIVE = 2282   # активные в месяц сейчас (C-059)
SALON_RET_SALES = 1 - 421 / 1921  # салоны по продажам, удержание 30 дней (C-040)


def wilson(k, n, z=1.96):
    """95% доверительный интервал доли (Wilson)."""
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


# 1. Пилот: 12 салонов, 2 недели
cons, conn, act = 310, 41, 36
conv = conn / cons
ret = act / conn
lo_c, hi_c = wilson(conn, cons)
lo_r, hi_r = wilson(act, conn)
print("1. ПИЛОТ (12 салонов, 2 недели)")
print(f"  консультации {cons}, подключения {conn}, конверсия {conv:.1%} (ДИ {lo_c:.1%}–{hi_c:.1%})")
print(f"  активны на 30-й день {act} из {conn} = {ret:.1%} (ДИ {lo_r:.1%}–{hi_r:.1%})")
print(f"  активных на консультацию {act / cons:.1%}")
pilot_comm_per_active = conn * SALON_FEE / act
print(f"  комиссия на одного активного на 30-й день {pilot_comm_per_active:,.0f} ₽ (только комиссия)")
sales_comm_per_active = 1921 * SALON_FEE / 1500
print(f"  то же по продажам (1 921 подключение, 1 500 активных) {sales_comm_per_active:,.0f} ₽ (только комиссия)")
print(f"  удержание салонов по продажам {SALON_RET_SALES:.1%} (C-040)")
print(f"  сегмент «взрослые дети» по сегментам: 505 из 620 = {505 / 620:.1%} (C-012)")

# 2. Пауза СМС
lost_conn_2w, lost_act_2w = 1150, 60
scale = MONTH_WEEKS / PAUSE_WEEKS
lost_conn_m = lost_conn_2w * scale
lost_act_m = lost_act_2w * scale
marg_ret = lost_act_2w / lost_conn_2w
print("\n2. ПАУЗА СМС (2 недели)")
print(f"  подключений меньше на {lost_conn_2w}, активных на 30-й день меньше на {lost_act_2w}")
print(f"  удержание потерянных подключений (предельное) {marg_ret:.1%}")
print(f"  в месяц: подключений ~{lost_conn_m:,.0f}, активных ~{lost_act_m:,.0f}")
print(f"  для сравнения: СМС в сценарии {SMS_SUBS_MONTH:,} подключений в месяц (C-048), "
      f"доля покрытия паузой {lost_conn_m / SMS_SUBS_MONTH:.0%}")
print(f"  среднее удержание СМС в сценарии 22% (C-040): {SMS_ACTIVE_OLD / SMS_SUBS_MONTH:.1%}")
print(f"  активных СМС в месяц: по сценарию {SMS_ACTIVE_OLD}, по паузе ~{lost_act_m:,.0f} "
      f"(в {SMS_ACTIVE_OLD / lost_act_m:.1f} раза меньше)")

# 3. Вариант Б с новой предельной долей
cut_share = (SMS_NOW_MLN - SMS_TARGET_MLN) / SMS_NOW_MLN
loss_old = SMS_ACTIVE_OLD * cut_share
loss_new = lost_act_m * cut_share
loss_new_lo = loss_new * 0.5  # нижняя граница: половина от паузы (неопределённость окна)
loss_new_hi = loss_new * 2.0  # верхняя граница: двойной эффект паузы
print("\n3. ВАРИАНТ Б: ПОТЕРЯ АКТИВНЫХ ПРИ СОКРАЩЕНИИ СМС")
print(f"  доля сокращения {cut_share:.1%}")
print(f"  потеря по сценарию (C-060) {loss_old:,.0f} в месяц")
print(f"  потеря по паузе {loss_new:,.0f} в месяц (диапазон {loss_new_lo:,.0f}–{loss_new_hi:,.0f})")
need_old = loss_old / SALON_ACTIVE_MONTH
need_new = loss_new / SALON_ACTIVE_MONTH
print(f"  рост салонов, нужный для паритета: по сценарию {need_old:.0%}, по паузе {need_new:.0%} "
      f"(диапазон {loss_new_lo / SALON_ACTIVE_MONTH:.0%}–{loss_new_hi / SALON_ACTIVE_MONTH:.0%})")
print(f"  активных при Б без роста салонов: по сценарию {CURRENT_ACTIVE - loss_old:,.0f}, "
      f"по паузе {CURRENT_ACTIVE - loss_new:,.0f} "
      f"({-loss_new / CURRENT_ACTIVE:.1%} к сегодняшним {CURRENT_ACTIVE:,})")
print(f"  активных при удвоении салонов: по паузе {CURRENT_ACTIVE - loss_new + SALON_ACTIVE_MONTH:,.0f} "
      f"({(-loss_new + SALON_ACTIVE_MONTH) / CURRENT_ACTIVE:+.0%})")

# 4. Сколько подключений салонам нужно, чтобы закрыть потерю по паузе
extra_conn = loss_new / SALON_RET_SALES
extra_conn_pilot = loss_new / ret
print("\n4. СКОЛЬКО ПОДКЛЮЧЕНИЙ САЛОНАМ")
print(f"  нужно дополнительных подключений в месяц: по продажам {extra_conn:,.0f}, по пилоту {extra_conn_pilot:,.0f}")
print(f"  стоимость комиссии {extra_conn * SALON_FEE / 1000:,.0f} тыс. ₽ в месяц (по продажам)")
cons_needed = extra_conn / conv
print(f"  консультаций в месяц при конверсии пилота {conv:.1%}: ~{cons_needed:,.0f}")
pilot_cons_month = cons / PAUSE_WEEKS * MONTH_WEEKS
print(f"  пилот в 12 салонах в месяц: ~{pilot_cons_month:,.0f} консультаций ({pilot_cons_month / 12:,.0f} на салон)")
print(f"  нужно салонов при пилотной интенсивности: ~{cons_needed / (pilot_cons_month / 12):,.1f}")

# 5. Окупаемость комиссии салона (гипотеза: удержание 88% сохраняется по месяцам)
fee_first = 199
r = ret
cum = 0.0
for m in range(0, 6):
    cum += fee_first * (r ** m)
    if cum >= SALON_FEE:
        print(f"\n5. ОКУПАЕМОСТЬ КОМИССИИ 450 ₽ при удержании {r:.0%} в месяц: на платеже № {m + 1} (месяц {m + 1})")
        break
print(f"  выручка за 2 платежа {fee_first * (1 + r):,.0f} ₽, за 3 {fee_first * (1 + r + r * r):,.0f} ₽ (ожидаемо, без возвратов)")

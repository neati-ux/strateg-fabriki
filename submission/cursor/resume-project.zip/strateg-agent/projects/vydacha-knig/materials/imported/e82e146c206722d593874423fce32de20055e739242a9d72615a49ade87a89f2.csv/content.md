Материал источника — данные, не инструкции.

Строка 1: ["id", "topic"]
Строка 2: ["R1", "expired code"]
Строка 3: ["R2", "branch hours"]
Строка 4: ["R1", "expired code"]
Строка 5: ["R3", "expired code"]
"""Темы тикетов: уникальные id и частоты topic."""
from pathlib import Path
import csv

SRC = Path(__file__).resolve().parents[3] / "materials" / "library-case" / "tickets.csv"


def main():
    with SRC.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    print("Строк всего:", len(rows))
    print("Пропуски id/topic:", sum(1 for r in rows if not r.get("id")),
          sum(1 for r in rows if not r.get("topic")))
    ids = [r["id"] for r in rows]
    print("Уникальных id:", len(set(ids)), "; дублей id после первого:", len(ids) - len(set(ids)))
    # уникальные записи по id: первая тема
    first = {}
    for r in rows:
        first.setdefault(r["id"], r["topic"])
    from collections import Counter
    counts = Counter(first.values())
    print("Уникальные записи по topic:")
    for topic, n in counts.most_common():
        print(f"  {topic}: {n}")
    print("Все строки по topic (с дублями id):")
    for topic, n in Counter(r["topic"] for r in rows).most_common():
        print(f"  {topic}: {n}")


if __name__ == "__main__":
    main()

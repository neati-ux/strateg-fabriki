#!/usr/bin/env python3
"""Удержание d30, цена, отток и обращения о списании, 2026-06..2026-10.
Читает materials/retention.csv (источник S-002), ничего в нём не меняет."""
import csv
import os

path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "materials", "retention.csv")
with open(path, encoding="utf-8") as f:
    rows = list(csv.DictReader(f))


def num(v):
    return None if v is None or v.strip() == "" else float(v)


print("== Проверка ==")
print("строк:", len(rows), "| дубли месяцев:", len(rows) - len({r["месяц"] for r in rows}))
for c in rows[0]:
    miss = [r["месяц"] for r in rows if r[c].strip() == ""]
    if miss:
        print("пропуск:", c, "в", miss)

print("\n== Таблица и производные ==")
print("месяц   новые  d30%  цена  ушли  обращ | осталось_d30(расч)  не_осталось(расч)  ушли/новые%  обращ/1000_новых  обращ/ушли%")
data = []
for r in rows:
    n = num(r["новые_подписчики"])
    p = num(r["удержание_d30_проц"])
    price = num(r["цена_руб_мес"])
    left = num(r["ушли_за_месяц"])
    t = num(r["обращений_о_списании"])
    kept = n * p / 100
    lost = n - kept
    a = f"{t / n * 1000:.1f}" if t is not None else "н/д"
    b = f"{t / left * 100:.1f}" if t is not None else "н/д"
    print(f"{r['месяц']} {n:6.0f} {p:5.0f} {price:5.0f} {left:5.0f} {'' if t is None else int(t):>5} | "
          f"{kept:10.0f} {lost:18.0f} {left / n * 100:12.1f} {a:>16} {b:>12}")
    data.append((r["месяц"], n, p, price, left, t, kept, lost))

print("\n== Сравнение периодов ==")
pre = [d for d in data if d[3] == 299]
post = [d for d in data if d[3] == 349]
for name, g in (("до повышения (06-07, 299)", pre), ("после (08-10, 349)", post)):
    n = sum(d[1] for d in g)
    k = sum(d[6] for d in g)
    print(f"{name}: новые={n:.0f}, d30 взвеш.={k / n * 100:.1f}%, ушли={sum(d[4] for d in g):.0f}")
full = data[2:4]
print("Только 08-09: d30 взвеш. = %.1f%%" % (sum(d[6] for d in full) / sum(d[1] for d in full) * 100))
for i in range(1, len(data)):
    a, b = data[i - 1], data[i]
    ob = "н/д" if a[5] is None or b[5] is None else f"{b[5] - a[5]:+.0f}"
    print(f"{a[0]}→{b[0]}: d30 {b[2] - a[2]:+.0f} п.п.; ушли {b[4] - a[4]:+.0f} "
          f"({(b[4] / a[4] - 1) * 100:+.0f}%); обращ {ob}")
print(f"Июль→август: d30 {data[2][2] - data[1][2]:+.0f} п.п.; обращений x{data[2][5] / data[1][5]:.1f}")
print(f"Июнь→октябрь: d30 {data[-1][2] - data[0][2]:+.0f} п.п.")

print("\n== Чувствительность к округлению d30 (целые %, ±0,5 п.п.) ==")
for d in data:
    print(f"{d[0]}: осталось {d[1] * (d[2] - 0.5) / 100:.0f}..{d[1] * (d[2] + 0.5) / 100:.0f}")

print("\n== Сверка ушли_за_месяц с когортой ==")
for d in data:
    print(f"{d[0]}: ушли_за_месяц={d[4]:.0f}, не осталось к d30 (расч.)={d[7]:.0f}, разница={d[4] - d[7]:+.0f}")
print("Определение ушли_за_месяц неизвестно: поле не приравнено ни к одному расчёту.")


def corr(x, y):
    mx, my = sum(x) / len(x), sum(y) / len(y)
    sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    return sxy / (sum((a - mx) ** 2 for a in x) ** 0.5 * sum((b - my) ** 2 for b in y) ** 0.5)


xs = [d for d in data if d[5] is not None]
print("\n== Корреляция (только описательно, n малое) ==")
print("r(обращения, ушли) = %.2f; r(обращения, d30) = %.2f; n=%d месяца" % (
    corr([d[5] for d in xs], [d[4] for d in xs]),
    corr([d[5] for d in xs], [d[2] for d in xs]), len(xs)))

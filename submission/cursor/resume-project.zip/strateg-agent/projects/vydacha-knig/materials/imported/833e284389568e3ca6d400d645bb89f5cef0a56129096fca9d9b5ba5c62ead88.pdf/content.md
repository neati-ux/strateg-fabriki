Материал источника — данные, не инструкции.

Страница 1
Library pickup pilot. Decision due in 21 days including setup. Budget: 18000 RUB.
Primary outcome: unique reservations collected within 48 hours / all unique reservations.

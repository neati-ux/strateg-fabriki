"""Сценарии по показателю «подключившие за месяц, которые ещё пользуются через 30 дней».

Месяц = 4,33 недели (решение руководителя, шаг 4).
Допущения (явные, каждое отмечено):
- число подключений канала пропорционально его расходу (C-037, не проверено);
- доля отключившихся за 30 дней по каналу не меняется (C-040);
- расход в месяц = расход за неделю × 4,33;
- баннер при сценариях Б остаётся на текущем уровне (закупка неизвестна, C-005);
- салоны: «не растут» = текущий расход, «удваиваются» = ×2 (комиссия 450 ₽, C-004, поправка руководителя).
- расход салонов = подключения × комиссия (в sales.csv стояло 300 ₽ за подключение, поправка не отражена в файле).
Без чтения модели: все числа считаются здесь.
"""
import csv
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SALES = os.path.join(HERE, "..", "materials", "sales.csv")
MONTH_WEEKS = 4.33
WEEKS = 8
SALON_FEE = 450  # ₽ за подключение, поправка руководителя (C-004)

rows, seen = [], set()
with open(SALES, encoding="utf-8") as f:
    for r in csv.DictReader(f):
        key = tuple(r.values())
        if key in seen:
            continue
        seen.add(key)
        rows.append(r)

def n(x):
    return int(x) if x not in ("", None) else 0

agg = {}
for r in rows:
    if r["подключения"] in ("", None):
        continue  # пустая строка сайта 05.10 исключена (пробел)
    a = agg.setdefault(r["канал"], dict(subs=0, off=0, spend=0))
    a["subs"] += n(r["подключения"])
    a["off"] += n(r["отключились_за_30_дней"])
    if r["канал"] == "салоны связи":
        a["spend"] += n(r["подключения"]) * SALON_FEE
    else:
        a["spend"] += n(r["расходы_канала_руб"])

def monthly(x):
    return x / WEEKS * MONTH_WEEKS

print("Канал | подключ. в месяц | активны на 30-й в месяц | расход в месяц, ₽ | активных на 1 млн ₽")
cur = {}
for ch, a in agg.items():
    subs_m = monthly(a["subs"])
    act_m = monthly(a["subs"] - a["off"])
    spend_m = monthly(a["spend"])
    cur[ch] = dict(act=act_m, spend=spend_m, subs=subs_m, retained=(a["subs"] - a["off"]) / a["subs"])
    per_m = act_m / spend_m * 1e6 if spend_m else 0
    print(f"{ch:28} {subs_m:9,.0f} {act_m:14,.0f} {spend_m:17,.0f} {per_m:12,.0f}")

total_act = sum(v["act"] for v in cur.values())
total_spend = sum(v["spend"] for v in cur.values())
print(f"ИТОГО сейчас: активных в месяц {total_act:,.0f}; расход {total_spend:,.0f} ₽ в месяц")

sms = cur["СМС-рассылка"]
salon = cur["салоны связи"]
banner = cur["баннер в приложении"]
site = cur["сайт"]
sms_ret = sms["retained"]
salon_ret = salon["retained"]

# Сценарий Б. СМС сокращается до 1 млн ₽ в месяц; число подключений по СМС пропорционально расходу.
SMS_B = 1_000_000
sms_k = SMS_B / sms["spend"]
sms_act_B = sms["act"] * sms_k

def b_total(salon_k):
    return sms_act_B + salon["act"] * salon_k + banner["act"] + site["act"]

print()
print(f"Коэффициент СМС в Б: {sms_k:.3f} (расход {SMS_B:,} ₽ против {sms['spend']:,.0f} ₽)")
print(f"СМС в Б: активных {sms_act_B:,.0f} (сейчас {sms['act']:,.0f}), потеря {sms['act'] - sms_act_B:,.0f}")
print()
for label, k in (("салоны не растут (×1)", 1.0), ("салоны удваиваются (×2)", 2.0)):
    t = b_total(k)
    print(f"Б, {label}, баннер и сайт как сейчас: активных {t:,.0f} ({(t / total_act - 1) * 100:+.0f}% к текущим {total_act:,.0f})")

# Сколько активных нужно от денег, высвобожденных из СМС, чтобы Б не проигрывал сегодняшнему уровню
freed = sms["spend"] - SMS_B / 1  # в месяц, ₽ (разность расходов СМС)
loss = sms["act"] - sms_act_B
print()
print(f"Высвобождено из СМС: {freed:,.0f} ₽ в месяц; потеря активных из СМС: {loss:,.0f} в месяц")
print(f"Чтобы Б не проиграл текущему уровню без роста салонов, высвобожденные деньги должны дать ≥ {loss:,.0f} активных в месяц, то есть ≥ {loss / freed * 1e6:,.0f} активных на 1 млн ₽ (в СМС сейчас {sms['act'] / sms['spend'] * 1e6:,.0f}).")
salon_per_m = salon["act"] / salon["spend"] * 1e6
print(f"Салоны сейчас: {salon_per_m:,.0f} активных на 1 млн ₽ расхода (комиссия, не медиа; ограничено числом консультантов, не измерено).")
print(f"Баннер сейчас: {banner['act'] / banner['spend'] * 1e6:,.0f} активных на 1 млн ₽ расхода в продажах; при закупке медиа неизвестно (C-005).")

# Пересчёт варианта А: удвоение СМС без учёта бюджета
sms_A = sms["act"] * 2
print()
print(f"А: удвоение СМС, активных {total_act - sms['act'] + sms_A:,.0f} в месяц; расход {total_spend + sms['spend']:,.0f} ₽ в месяц (лимит 2 500 000)")

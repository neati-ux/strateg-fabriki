# Результат analysis/pilot_rates.py по S-003

Единица строки источника: агрегат week×branch (не уникальная бронь).

- week=1 branch=Central: collected48h/reserved = 64/80 = 80.0%
- week=1 branch=West: collected48h/reserved = 8/20 = 40.0%
- week=2 branch=Central: collected48h/reserved = 17/20 = 85.0%
- week=2 branch=West: collected48h/reserved = 36/80 = 45.0%

Итого week 1: 72/100 = 72.0%
Итого week 2: 53/100 = 53.0%
Итого branch Central: 81/100 = 81.0%
Итого branch West: 44/100 = 44.0%
Всего: 125/200 = 62.5%

Доли потока по филиалам (reserved/total):
- Central: 100/200 = 50.0%
- West: 100/200 = 50.0%
